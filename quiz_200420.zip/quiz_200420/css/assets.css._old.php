<?php 
define( '_QEXEC', 1 );
$p=dirname(__FILE__);
$p1=explode("/",$p);
array_pop($p1);
array_pop($p1);

define('QPATH_BASE', implode("/",$p1));


define( 'DS', DIRECTORY_SEPARATOR );
define('QPATH_COMPONENTI', QPATH_BASE.DS.'componenti' );

require_once ( QPATH_BASE .DS.'config.php' );
require_once ( QPATH_BASE .DS.'lib'.DS.'setup.php' );

require_once ( QPATH_COMPONENTI.DS.'editor/model.php' );

$id=$_GET["id"];

$lezione=new Lezione($id);

		$t=explode("|",$lezione->stili);
		
		$titolo_colore=$t[1];
		$titolo_dimensione=$t[2];
		
		
		$testo_colore=$t[4];
		$testo_dimensione=$t[5];
		
		$fascia_colore=$t[6];
		$fascia_colore_testo=$t[7];

		$box_testo=$t[8];
		
		
header("Content-Type: text/css");
?>
/* GENERALE */

p {margin:0 0 1em 0}

#asset_consegna,.asset_consegna {color: #000; font-size:16px; border-bottom:1px solid black; padding-bottom:4px; margin-bottom:20px; font-weight:bold; margin-top:15px;min-height:17px;}
#player input {	height:2em; line-height:2em;text-align:center;display:inline;	position:relative; margin:0; vertical-align:middle; border-radius:5px;-moz-border-radius:5px;	-webkit-border-radius:5px;	border:1px solid #16A0C8;}
sup { line-height:12px; overflow:visible;}
#asset_opzioni,.asset_opzioni {margin-top:15px; margin-right:15px;}
#player ol {margin: 20px 0 20px 40px; }
#player ol li {display: list-item;  margin:0 0 5px 0; list-style-type:decimal!important;}

#player_contenuto ul {margin: 20px 0 20px 40px; }
#player_contenuto ul li {display: list-item; list-style-type:circle!important; margin:0 0 5px 0;	}
#player_contenuto ul.ui-droppable li {display: list-item; list-style-type:none!important; margin:0 0 5px 0;	}

#player_contenuto { font-size:14px;}
#player_contenuto a {color:#0000EE; text-decoration:underline;  font-size:14px;}
#player_contenuto a:hover { text-decoration:none; color:#0000EE;}

#player_testo_domanda { margin-right:15px; line-height:23px;}
#player_testo_domanda .sbagliato { color:red;}
#player_testo_domanda .giusto { color:green;}

#player_contenuto .feedback p { font-size:12px;}
.punteggio {position:absolute; bottom:120px; right:15px; font-size:16px;}
.punteggio span { font-size:18px; display:block;}


/* FEEDBACK */
.lampadina{background: url("../img/icon_lampadina.png") center no-repeat; width:15px; height:23px; display:inline-block;margin: 0 0 -5px 4px; }
#lampadina:hover { cursor:pointer; }
.ui-dialog .lampadina {display:none;}

.aiuto1 {background: url("../img/icona_aiuto.png") center no-repeat; width:20px; height:20px; position:absolute;
top:60px;right:23px; cursor:pointer;}
.aiuto {background: url("../img/icona_aiuto.png") center no-repeat; width:20px; height:20px; float:right; position:relative; margin-top:-24px;margin-right:23px; cursor:pointer;}

/* SCELTA MULTIPLA */
.player_input {	float:left;	margin-right:1em; margin-left:1em; display:block; }
.opzionemultiple {margin:0; padding:0;display:inline-block;}
.opzionemultiple p {margin:0; line-height:23px;}
.opzionemultiple.giusto { border:1px solid green; padding:4px; border-radius:7px; max-width:80%; display:inline-block; }
.opzionemultiple.sbagliato {  border:1px solid red; padding:4px; border-radius:7px; max-width:80%; display:inline-block;} 
.player_opzione {margin:0; padding:0;display:inline-block;}
.player_opzione p, #asset_opzioni p { margin:0; line-height:23px;}
.player_opzione_separatore_feedback {clear:both;display:block; height:10px; margin-top:5px; margin-bottom:7px;}
.player_opzione_separatore {clear:both; display:block; height:10px; margin-top:5px; margin-bottom: 7px;}
#player_opzioni_domanda {padding:10px; display:block;}
.player_opzione.giusto { border:1px solid green; padding:4px; border-radius:7px; max-width:80%; display:inline-block; }
.player_opzione.sbagliato {  border:1px solid red; padding:4px; border-radius:7px; max-width:80%; display:inline-block;} 
.icona_sbagliato { background:transparent url(../img/icona_not_ok.png) top left no-repeat; width:20px; height:20px; display:inline-block;margin: 0 0 -4px 6px;}
.icona_giusto {background:transparent url(../img/icona_ok.png) top left no-repeat;width:20px; height:20px; display:inline-block;margin: 0 0 -4px 6px;}


/* ASSOCIAZIONI*/
#asset_opzioni table.associazione {width:380px;}
#asset_opzioni table.associazione2 {width:300px;}
#asset_opzioni .associazione td.titolo_riga { max-width:150px;width:150px; min-height:50px; padding: 15px; background-color: #E9F7FA; border: 1px solid #16A0C8;border-radius:5px; -moz-border-radius:5px; -webkit-border-radius:5px;}
#asset_opzioni .associazione td.dropmatch {border:2px dashed #ccc;	padding:5px; 	height:50px; min-height:50px;	line-height:39px; border-radius:5px; -moz-border-radius:5px; -webkit-border-radius:5px;}

#asset_opzioni .tabella_dd td.drag_td {max-width:150px;width:150px; min-height:50px;}
#asset_opzioni .dragmatch {background-color: #E9F7FA; max-width:150px;width:150px; min-height:50px; padding:10px; cursor:move; z-index:100; border-radius:5px; -moz-border-radius:5px; -webkit-border-radius:5px; border: 1px solid #16A0C8;}

#asset_opzioni .tabella_dd { border-collapse: separate; border-spacing:10px 10px;}
#asset_opzioni .tabella_dd td { height:19px; vertical-align:top; margin-right:10px;}
#asset_opzioni .tabella_dd td.dato { padding:5px; text-align:right; background-color:#EBECED; border-right:2px solid #fff; }
#asset_opzioni .tabella_dd td.azione_tabella {width:30px; text-align:center; vertical-align:top; background-color: #EBECED; padding:5px 0 0 0px; }
#asset_opzioni .tabella_dd td.titolo_riga.contenutolnd, .tabella_dd td.dato.contenutolnd, .tabella_dd td.azione_tabella.contenutolnd { background-color: #fce504; }
#asset_opzioni .tabella_dd tr.tDnD_whileDrag td { background-color: #eee; border: 1px dotted #ccc; }
#asset_opzioni .tabella_dd tr.alt td {background-color: #ecf6fc;}
#asset_opzioni .tabella_dd .giusto { color:green;}
#asset_opzioni .tabella_dd .sbagliato { color:red;}
#asset_opzioni .tabella_dd .icona_giusto{ background:transparent url(../img/icona_ok.png) left no-repeat; width:20px; height:20px; position:absolute; margin-left:3px;}
#asset_opzioni .tabella_dd .icona_sbagliato{ background:transparent url(../img/icona_not_ok.png) left no-repeat; width:20px; height:20px; position:absolute;margin-left:3px;}


/* DRAG&DROP TESTUALE */
#testoDD,.testoDD {clear:both;margin:35px 0 0 0;}
ul.boxy { list-style:none; left:20%; padding: 4px 4px 0 4px; margin: 0px; height: auto; text-align: center;font-size: 14px; font-family: Arial, sans-serif; font-weight: bold;}
ul.boxy li { cursor:move;float: left; margin-right: 4px; margin-bottom: 4px; padding:2px 12px 2px 12px;    border: #100 1px dotted; background-color: #E9F7FA;z-index:100;}
.inputBoxDD {height:2em;border-top-style: solid;border-top-color: #FFFFFF;border-top-width: 0px; border-right-style: solid; border-right-color: #FFFFFF; border-right-width: 0px; border-left-style: solid; border-left-color: #FFFFFF; border-left-width: 0px; border-bottom-style: solid; border-bottom-color: #000000; border-bottom-width: 1px;}
input.inputBoxDD {color:#000; font-weight:bold;}
input.inputBoxDD.sbagliato {background:transparent url(../img/icona_not_ok.png) 95% no-repeat; }
input.inputBoxDD.giusto {background:transparent url(../img/icona_ok.png) 95% no-repeat; 	}
#testoDD .giusto { border:1px solid green; padding:2px;border-radius:5px;-moz-border-radius:5px;	-webkit-border-radius:5px; line-height:26px;}


/* RIORDINA */
#asset_opzioni #player_tabella_item { list-style-type: none; margin: 0; padding: 0; width:450px;}
#asset_opzioni #player_tabella_item li { list-style-type: none!important; background-color:#fff; margin-bottom:5px; padding: 12px; border:1px solid #16A0C8;cursor:move;border-radius:5px; -moz-border-radius:5px; -webkit-border-radius:5px;}
#asset_opzioni #player_tabella_item li p { padding-right:15px; line-height:17px;}
#asset_opzioni #player_tabella_item td p {padding-right:15px;}
/*#asset_opzioni #player_tabella_item li span { position: absolute; margin-left: -1em;}*/
#asset_opzioni #player_tabella_item .giusto { background:transparent url(../img/icona_ok.png) 99% no-repeat; }
#asset_opzioni #player_tabella_item .sbagliato { background:transparent url(../img/icona_not_ok.png) 99% no-repeat; }


/* DOMANDA APERTA */
textarea {border:1px solid #16A0C8;	border-radius:5px; -moz-border-radius:5px; -webkit-border-radius:5px;}


/* AUDIO VIDEO */
div.jp-audio, div.jp-video {margin-bottom:20px; margin-top:20px;}


/* VERO FALSO*/
#asset_opzioni #table_options td{ padding-top:5px; padding-bottom:5px;}
#asset_opzioni #table_options th{ padding:0 10px; font-weight:bold; color:#009;}
#asset_opzioni #table_options th:nth-child(3), th:nth-child(4), th:nth-child(5), th:nth-child(6){ padding:0 20px; }
#asset_opzioni #table_options td.label{ vertical-align:top; line-height: 23px; width:27px; }
#asset_opzioni #table_options td.question{vertical-align:top; width:380px; }
#asset_opzioni #table_options .icona_giusto{ background:transparent url(../img/icona_ok.png) left no-repeat; width:20px; height:20px; position:absolute; margin-left:3px;}
#asset_opzioni #table_options .icona_sbagliato{ background:transparent url(../img/icona_not_ok.png) left no-repeat; width:20px; height:20px; position:absolute;margin-left:3px;}


/* INTRUSO */
.intruso {color: #ff0000;}
.intruso1 {color:#fff;background-color:#364395;}
.intruso2 {color:#fff;background-color:#16A0C8;}
.intruso3 {color:#fff;background-color:#9d1548;}
.intruso4 {color:#fff;background-color:#ed6c00;}
.intrusodarispondere1 {color:#364395; background-color: #ccc; }
.intrusodarispondere2 {color:#16A0C8; background-color: #ccc; }
.intrusodarispondere3 {color:#9d1548; background-color: #ccc; }
.intrusodarispondere4 {color:#ed6c00; background-color: #ccc; }


/* COMPLETAMENTO LIBERO/GUIDATO*/
#asset_testo .soluzione.giusto { border:1px solid green; padding:2px;border-radius:5px;-moz-border-radius:5px;	-webkit-border-radius:5px; line-height:26px;}
select.giusto {border:1px solid green; color:green; }
select.sbagliato {border:1px solid red; color:red;}
#asset_testo input.sbagliato { background:transparent url(../img/icona_not_ok.png) 98% no-repeat;}
#asset_testo input.giusto {background:transparent url(../img/icona_ok.png) 98% no-repeat;}


/* TESTO LIBERO*/
#asset_testo { margin-right:15px; line-height:22px;max-width:900px;margin-bottom:1em;}
#testo_libero { margin-right:15px; margin-left:47px;}


/* VARIE */
#svgbasics {position: absolute;left: 0px; top: 0px;border: solid 0px #484; z-index: -100;}
.nopadding {padding:0;}
.alto {	margin-bottom:15px;}
.piede_domanda {clear:both;	margin:10px 0 10px 10px;float:right;}
.testonormale {	font-family:Verdana,Arial,Helvetica,sans-serif;	font-size:0.9em;color:#707172;font-style:normal;	font-weight:normal;line-height:2em;}
#contenitore_domanda {display:block;height:100%;}
.hotspotsel {display:block;border:1px solid #ff0000;position:absolute;}
.hotspotselcontent {filter: alpha(opacity=20);opacity: 0.2;background-color:#000000;width:20px;height:20px;}
.disattivato {	display:none;}
iframe.file_upload {border:none;width:580px;height:400px;overflow:auto;}
.flex_container {padding:5px;}
select[multiple] {height:300px;width:200px;	}
.correzione_spazio {font-size:0.8em;color:#707172;}
#banner h1 {margin:0;text-align:right;font-family: 'Helvetica'; font-size:24px; color:#fff;padding:7px 10px 0 0;}
#elenco_risposte { margin-top: 10px; }
td.dragHandle { width: 19px; height: 19px; }
td.showDragHandle { /*background-image: url(../img/ico_riordina.png); background-repeat: no-repeat; background-position: center center;*/ cursor: move; }
#drawer {float:left;width:30px;height:30px;margin:-15px 0px 0 -15px;z-index:100;}
#drawer a {display:block;width:30px;height:30px;background:transparent url(../img/drawer_icon.png) top left no-repeat;}
#drawer a span {display:none;}
#myBoxes { text-align:left;}

#area_interazione {width:700px;	height:100%;}

.delSelezione img{ margin-bottom:5px; }
#intrusi_space { margin-top:15px!important; }

.didascalia, div.didascalia+p, figcaption {
	text-align:center;
	font-size:0.8em;
	font-style:italic;
}



.media_container {
	width:100%;
	text-align:center;
	margin:1em;
}

.citazione {
	font-size:0.9em;
	margin:1em;
	padding:1em;
	font-style:italic;
}


.rientro {
	text-indent:1em;
}

img {border:none;}

.sinistra_40 img,.destra_40 img,.sinistra img,.destra img,.full img,.full_width img,.centro_70 img {
	width:100%;	
}

.full_height img {
	height:100%;	
}


.sinistra_40 {
	float:left;
	margin:0 1em 1em 0;
	width:40%;
}

.destra_40 {
	float:right;
	margin:0 0 1em 1em;
	width:40%;
}

.sinistra {
	float:left;
	margin:0 1em 1em 0;
}

.destra {
	float:right;
	margin:0 0 1em 1em;
}

.centro {
	display:block;
	clear:both;
	margin:1em auto;
	padding:5px;
	text-align:center;
}


.full,.full_width {
	display:block;
	clear:both;
	width:100%;
	margin:0 0 1em 0;	
}

.nota {
	font-size:0.8em;
}

.linknota {
	font-size:0.8em;
}

.nascosto {
	display:none;
}


table {
	border:1px solid #ccc;
	border-collapse:collapse;
}

table td,  table th {
	border:1px solid #ccc;
	padding:10px;
}

#asset_opzioni table {
	border:none;
	border-collapse:collapse;
}

#asset_opzioni table td,  #asset_opzioni table th {
	border:none;
	padding:5px 0 5px 0;
}

#player_contenuto .nota a {
	font-size:0.9em;
}


.box_sx {
	float:left;
	width:40%;
	border:1px solid #ccc;
	padding:1em;
	background-color:<?php echo $box_testo; ?>;
	margin:1em 1em 1em 0;
}

.box_dx {
	float:right;
	width:40%;
	border:1px solid #ccc;
	padding:1em;
	background-color:<?php echo $box_testo; ?>;
	margin:1em 0 1em 1em;
}

a,.link_blu {color: #0066CC;text-decoration: none;}
a:visited {color: #147;text-decoration: none;}

a[href^="http:"], a[href^="https:"], .link_rosso,
a[href^="http:"]:visited, a[href^="https:"]:visited
{
color:#C00;
border-bottom:1px dotted #C00;
-webkit-text-fill-color: #C00;
}

#copyright a {
	border-bottom:none;
	color:#0066CC;
}

.Wirisformula {
	display:inline;
	margin:0 0.5em 0 0.5em;
}


ul.boxy li {
	list-style-type:none!important;
}

.full_height {
	display:block;
	clear:both;
	height:100%;
	margin:0 auto;	
}

.centro_70 {
	display:block;
	clear:both;
	margin:0 auto;
	padding:5px;
	text-align:center;
	width:70%;
}

.box_center {
	display:block;
	margin:1em auto;
	width:50%;
	border:1px solid #ccc;
	padding:1em;
	background-color:<?php echo $box_testo; ?>;
}

.sintesi {
	border:1px solid #eee;
	padding:1em;
	font-size:0.9em;
	display:block;
	margin-bottom:1em;
}

#testo_libero .word.selected {
    background-color: #ffff00;
    cursor: pointer;
}​
